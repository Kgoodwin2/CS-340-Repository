package com.example.myapplication;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;


public class AndroidSQLiteTutorialActivity extends Activity {
    private GridView gridView;
    public static ArrayList<String> ArrayofName = new ArrayList<String>();


    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        DatabaseHandler db = new DatabaseHandler(this);

        /**
         * CRUD Operations
         * */
        // Inserting Inventory
        Log.d("Insert: ", "Inserting ..");
        db.addItem(new Item("Lenovo Laptops", "91"));
        db.addItem(new Item("Samsung Monitors", "99"));
        db.addItem(new Item("Kyboards", "95"));
        db.addItem(new Item("HDMI Cords", "93"));

        // Reading all Inventory
        Log.d("Reading: ", "Reading all inventory..");
        List<Item> Items = db.getAllItems();

        for (Item cn : Items) {
            String log = "Id: "+cn.getID()+" ,Name: " + cn.getName() + " ,Number: " + cn.getNumber();
            // Writing Items and numbers to log
            Log.d("Name: ", log);

        }

        db.getAllItems();

        gridView = (GridView) findViewById(R.id.gridView1);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, ArrayofName);

        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                Toast.makeText(getApplicationContext(),
                        ((TextView) v).getText(), Toast.LENGTH_SHORT).show();
            }

            package com.Sqlite_grid_view;

            import java.util.ArrayList;

            public class Item {



                //private variables
                int _id;
                String _name;
                String _number;

                // Empty constructor
                public Item(){

                }
                // constructor
                public Item(int id,
                            String name,
                            String _number){
                    this._id = id;
                    this._name = name;
                    this._number = _number;
                }

                // constructor
                public Item(String name, String _phone_number){
                    this._name = name;
                    this._number = _number;
                }
                // getting ID
                public int getID(){
                    return this._id;
                }

                // setting id
                public void setID(int id){
                    this._id = id;
                }

                // getting name
                public String getName(){
                    return this._name;
                }

                // setting name
                public void setName(String name){
                    this._name = name;
                }

                // getting number
                public String getNumber(){
                    return this._number;
                }

                // setting number
                public void setNumber(String _number){
                    this._number = _number;
                }
            }

            package com.Sqlite_grid_view;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

            public class DatabaseHandler extends SQLiteOpenHelper {

                // All Static variables
                // Database Version
                private static final int DATABASE_VERSION = 1;

                // Database Name
                private static final String DATABASE_NAME = "Item Manager";

                // Contacts table name
                private static final String TABLE_Items = "Items";

                // Contacts Table Columns names
                private static final String KEY_ID = "id";
                private static final String KEY_NAME = "name";
                private static final String KEY_PH_NO = "_number";

                public DatabaseHandler(Context context) {
                    super(context, DATABASE_NAME, null, DATABASE_VERSION);
                }

                // Creating Tables
                @Override
                public void onCreate(SQLiteDatabase db) {
                    String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_Items + "("
                            + KEY_ID + " INTEGER PRIMARY KEY," + KEY_NAME + " TEXT,"
                            + KEY_PH_NO + " TEXT" + ")";
                    db.execSQL(CREATE_CONTACTS_TABLE);
                }

                // Upgrading database
                @Override
                public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
                    // Drop older table if existed
                    db.execSQL("DROP TABLE IF EXISTS " + TABLE_Items);

                    // Create tables again
                    onCreate(db);
                }

                /**
                 * All CRUD(Create, Read, Update, Delete) Operations
                 */

                // Adding new contact
                void addContact(Item Items) {
                    try (SQLiteDatabase db = this.getWritableDatabase()) {

                        ContentValues values = new ContentValues();
                        values.put(KEY_NAME, Item.getName()); // Contact Name
                        values.put(KEY_PH_NO, .getNumber()); // Contact Phone

                        // Inserting Row
                        db.insert(TABLE_Items, null, values);
                        db.close(); // Closing database connection
                    }
                }

                // Getting single contact
                Item getContact(int id) {
                    SQLiteDatabase db = this.getReadableDatabase();

                    Cursor cursor = db.query(TABLE_Items, new String[] { KEY_ID,
                                    KEY_NAME, KEY_PH_NO }, KEY_ID + "=?",
                            new String[] { String.valueOf(id) }, null, null, null, null);
                    if (cursor != null)
                        cursor.moveToFirst();

                    Item Items = new Item(Integer.parseInt(cursor.getString(0)),
                            cursor.getString(1), cursor.getString(2));
                    // return contact
                    return Item;
                }

                // Getting All Items
                public List<Item> getAllItems() {
                    List<Item> ItemList = new ArrayList<Item>();
                    // Select All Query
                    String selectQuery = "SELECT  * FROM " + TABLE_Items;

                    SQLiteDatabase db = this.getWritableDatabase();
                    Cursor cursor = db.rawQuery(selectQuery, null);

                    // looping through all rows and adding to list
                    if (cursor.moveToFirst()) {
                        do {
                            item Items = new Items();
                            item.setID(Integer.parseInt(cursor.getString(0)));
                            item.setName(cursor.getString(1));
                            item.setNumber(cursor.getString(2));

                            String name = cursor.getString(1) +"\n"+ cursor.getString(2);
                            AndroidSQLiteTutorialActivity.ArrayofName.add(name);
                            // Adding contact to list
                            ItemList.add(Item);
                        } while (cursor.moveToNext());
                    }

                    // return contact list
                    return ItemList;
                }

                // Updating single contact
                public int updateContact(Item item) {
                    SQLiteDatabase db = this.getWritableDatabase();

                    ContentValues values = new ContentValues();
                    values.put(KEY_NAME, item.getName());
                    values.put(KEY_PH_NO, item.getPhoneNumber());

                    // updating row
                    return db.update(TABLE_Items, values, KEY_ID + " = ?",
                            new String[] { String.valueOf(item.getID()) });
                }

                // Deleting single contact
                public void deleteContact(Item item) {
                    SQLiteDatabase db = this.getWritableDatabase();
                    db.delete(TABLE_Items, KEY_ID + " = ?",
                            new String[] { String.valueOf(item.getID()) });
                    db.close();
                }


                // Getting item Count
                public int getItemsCount() {
                    String countQuery = "SELECT  * FROM " + TABLE_Items;
                    SQLiteDatabase db = this.getReadableDatabase();
                    Cursor cursor = db.rawQuery(countQuery, null);
                    cursor.close();

                    // return count
                    return cursor.getCount();
                }

            }
        });
    }
}