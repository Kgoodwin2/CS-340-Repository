package com.example.andy.myapplication;

import android.graphics.Point;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText email,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        Button click = findViewById(R.id.click);
        click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!email.getText().toString().isEmpty()&&(!password.getText().toString().isEmpty())) {
                    Toast.makeText(MainActivity.this, "Email Entered " +                                     email.getText().toString() + "Password " + password.getText().toString(), Toast.LENGTH_LONG).show();
                } else {
                    email.setError("Please Enter Email");
                    password.setError("Please Enter Password");
                }
            }
            public class MainActivity extends AppCompatActivity {
                @Override
                protected void onCreate(Bundle savedInstanceState) {
                    super.onCreate(savedInstanceState);
                    setContentView(R.layout.activity_main);
                }

                /** Transitioning to a new activity when button is clicked */
                public void sendMessage(View view) {
                    // Do something in response to button
                }

                public class MainActivity extends AppCompatActivity {
                    public static final String EXTRA_MESSAGE = "com.example.myapplication.MESSAGE";
                    @Override
                    protected void onCreate(Bundle savedInstanceState) {
                        super.onCreate(savedInstanceState);
                        setContentView(R.layout.activity_main);
                    }

                    /** Called when the user taps the Click button */
                    public void sendMessage(View view) {
                        Intent intent = new Intent(this, MainActivity.class);
                        EditText editText = (EditText) findViewById(R.id.editText);
                        String message = editText.getText().toString();
                        intent.putExtra(EXTRA_MESSAGE, message);
                        startActivity(intent);
                    }
                }
            }
        });
    }
}